@extends('ecommerce.back_end.layout.master')

@section('title','Login')

@section('content')
    @include('ecommerce.back_end.partials.required')

<form action="{{route('front_end.login.store')}}" method="POST">
    {{ csrf_field() }}
    <label for="email">Email : </label>
    <input type="text" name="email" value="{{old('email')}}"/>
    {{ $errors->first('email') }}
    <br />
    <label for="password">Password : </label>
    <input type="text" name="password" value="{{old('password')}}"/>
    {{ $errors->first('password') }}
    <br />
    <input type="submit" value="Submit" />
</form>
