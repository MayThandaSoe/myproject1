@extends('ecommerce.back_end.layout.master')

@section('title','Edit SubCategory')

@section('content')
    @include('ecommerce.back_end.partials.required')
    <form action="{{route('admin.subcategory.update',$subcategories->id)}}" class="form-horizontal col-md-6" method="post">
        <input type="hidden" name="_method" value="PUT">
        {{csrf_field()}}
        <div class="form-group">
            <input type="text" name="name" value="{{$subcategories->name}}" class="form-control">
        </div>
       <div class="form-group">

           <input type="text" name="categories_id" value="{{$subcategories->categories->name}}" readonly>

        </div>
        <div class="form-group">
            <label for="Sub Categories Name" class="control-label">Choose Category: </label>
            <div class="col-sm-9">
                <select name="categories_id" class="form-control" id="categories_id">
                    <option value="0">Select</option>
                    @foreach( $categories as $category )
                        <option value="{{ $category->id }}">{{ $category->name}}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="form-group">
            <button class="btn btn-primary" >Save</button>
        </div>
    </form>
    @endsection