@extends('ecommerce.back_end.layout.master')

@section('title','Create Sub Categories')

@section('content')
    @include('ecommerce.back_end.partials.required')
    <h4>Create Sub Categories</h4>
    <form action="{{route('admin.subcategory.store')}}" class="form-horizontal col-md-6" method="post">
           {{csrf_field()}}
        <div class="form-group">
            <label for="Sub Categories Name" class="control-label">Name: </label>
            <input type="text" name="name" value="{{old('name')}}">
        </div>
        <div class="form-group">
            <label for="Sub Categories Name" class="control-label">Choose Category: </label>
            <div class="col-sm-9">
                <select name="categories_id" class="form-control" id="categories_id">
                    @foreach( $categories as $category )
                        <option value="{{ $category->id }}">{{ $category->name}}</option>
                    @endforeach
                </select>
            </div>
        </div>
            <div class="form-group">
            <button class="btn btn-primary" >Save</button>
        </div>
    </form>
@endsection