@extends('ecommerce.back_end.layout.master')

@section('title','Show Sub Categoires')

@section('content')
    <h4>All Sub Categoires</h4>
    <a href="{{route('admin.subcategory.create')}}" class="btn btn-info">Create SubCategoires</a>
    <hr>
    @include('ecommerce.back_end.partials.alerts')
    @foreach($subcategories as $subcategory)
        <div class="form-group">
            <strong>{{$subcategory->name}}</strong>

              <strong>{{$subcategory->categories->name}}</strong>

            <a href="{{route('admin.subcategory.edit',$subcategory->id)}}" class="btn btn-info">Edit Categories</a>
            <form action="{{route('admin.subcategory.destroy',$subcategory->id)}}" method="post">
                <input type="hidden" name="_method" value="DELETE">
                {{csrf_field()}}
                <button class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this item?');">Delete</button>
            </form>
        </div>
    @endforeach
@endsection