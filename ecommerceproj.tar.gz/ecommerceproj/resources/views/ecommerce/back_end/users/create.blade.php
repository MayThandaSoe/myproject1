@extends('ecommerce.back_end.layout.master')

@section('title','Create Users')

@section('content')
    @include('ecommerce.back_end.partials.required')
        <h4>Create Users</h4>
        <form action="{{route('admin.user.store') }}" class="form-horizontal col-md-6" method="post">
            {{csrf_field()}}
            <div class="form-group">
                <label for="first_name" class="control-label col-sm-3">First Name : </label>
                <div class="col-sm-9">
                    <input type="text" name="first_name" value="{{old('first_name')}}"/>
                    {{ $errors->first('first_name') }}
                </div>
            </div>
            <div class="form-group">
                <label for="last_name" class="control-label col-sm-3">Last Name : </label>
                <div class="col-sm-9">
                    <input type="text" name="last_name" value="{{old('last_name')}}"/>
                    {{ $errors->first('last_name') }}
                </div>
            </div>
            <div class="form-group">
                <label for="email" class="control-label col-sm-3">Email : </label>
                <div class="col-sm-9">
                    <input type="text" name="email" value="{{old('email')}}"/>
                    {{ $errors->first('email') }}
                </div>
            </div>
            <div class="form-group">
                <label for="password" class="control-label col-sm-3">Password : </label>
                <div class="col-sm-9">
                    <input type="password" name="password" value="{{old('password')}}"/>
                    {{ $errors->first('password') }}
                 </div>
            </div>
            <div class="form-group" class="control-label col-sm-3">
                <label for="password_confirmation">Confirm Password : </label>
                <div class="col-sm-9">
                    <input type="password" name="password_confirmation" value="{{old('password_confirmation')}}" />
                    {{ $errors->first('confirm_password') }}
                </div>
            </div>
            <div class="form-group">
                <label for="Sub Categories Name" class="control-label">Choose Role: </label>
                <div class="col-sm-9">
                    <select name="role_id" class="form-control" id="role_id">
                        @foreach($roles as $role )
                            <option value="{{ $role->id }}">{{ $role->name}}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="col-sm-9 col-md-offset-3">
                <button type="submit" class="btn btn-primary">Save</button>
           </div>
    </form>
@endsection
