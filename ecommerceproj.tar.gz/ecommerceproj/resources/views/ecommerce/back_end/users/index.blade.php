@extends("ecommerce.back_end.layout.master")

@section("title","Show Users")


@section('content')
    <h4>All Users</h4>
    <a href="{{route('admin.user.create')}}" class="btn btn-info">Create Users</a>
    <hr>
    @include('ecommerce.back_end.partials.alerts')
    @foreach($users as $user)
        <div class="form-group">
            <strong>{{$user->first_name}}</strong>
            <strong>{{$user->last_name}}</strong>
            <strong>{{$user->email}}</strong>
            @if($user->role_id != "")
                <strong>{{$user->role->name}}</strong>
            @endif
            <a href='{{route('admin.user.edit',$user->id)}}' class="btn btn-info">Edit User</a>
            <form action="{{route('admin.user.destroy',$user->id)}}"  method="POST">
                <input type="hidden" name="_method" value="DELETE">
                {{csrf_field()}}
                <button class="btn btn-danger">Delete</button>
            </form>
        </div>
    @endforeach
@endsection