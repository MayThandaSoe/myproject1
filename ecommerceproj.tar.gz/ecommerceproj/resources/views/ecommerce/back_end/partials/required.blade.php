@if($errors->has())
    <div class="alert alert-danger" role="alert" align="center">
        <uL>
            @foreach ($errors->all() as $error)
                <li>{{ $error}}
            @endforeach
        </uL>
    </div>
@endif