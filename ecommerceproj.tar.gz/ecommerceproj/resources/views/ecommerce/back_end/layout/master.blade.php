<html5>
    <head>
    <title>
         @yield('title')
    </title>
    <link rel="stylesheet" href="/css/bootstrap.min.css">
        @yield('style')
    </head>
    <body>
      <div class="container">

          <div class="row" style="float: right">
              <div class="col-xs-12 text-a top-icon-bar">
                  <div class="btn-group" role="group" aria-label="...">
                      <a href="#" type="button" class="btn btn-default main-link">Log out<span class="icon  ic-switch"></span></a>
                  </div>
              </div>
          </div>
          <br>
          <br>
          <br>
          <div class="row">
              <div class="col-md-4">
          <div class="navbar-default sidebar " role="navigation">
              <div class="sidebar-nav navbar-collapse collapse " id="bs-example-navbar-collapse-1">
                  <div class="user-info"> </div>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#" class="btn btn-default" role="button" >Visit Site</a>
                  <ul class="nav" id="side-menu">
                      <li class="active">
                         <br> <a  href="#" ><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                      </li>

                      <li class="s-link ">
                          <a  href="#" class=""><i class="fa fa-edit fa-fw"></i> User  </a> </li>

                      <li class="s-link ">
                          <a  href="#" class=""><i class="fa fa-edit fa-fw"></i> Products  </a>
                      </li>

                      <li class="s-link ">
                          <a  href="#" class=""><i class="fa fa-edit fa-fw"></i> Categories  </a>
                      </li>
                      <li class="s-link ">
                          <a  href="#" class=""><i class="fa fa-edit fa-fw"></i> Sub Categories  </a>
                      </li>
                  </ul>

                  </li>
                  </ul>
              </div>


          </div>

          </div>

          <div class="col-md-8">
              <div id="content">
                  @yield('content')
              </div>
          </div>

                </div>




      </div>
        @yield('script')

    </body>
</html5>