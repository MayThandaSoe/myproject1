@extends('ecommerce.back_end.layout.master')

@section('title','Show Sub Categoires')

{{$total=0}}
{{$qty=0}}
{{$id=0}}
@section('content')



    @foreach($datas as $key=>$value)


    <input type="hidden" name="products" value="{{$products=\App\Models\Product::select ('id','product_name','product_price')->where('id','=',$value)->get()}}">



    @foreach($products as $product)

        <input type="hidden" name="pid" value="{{$pid=$product->id}}">
        @if($id == $pid)
           
        @endif
        @if($id != $pid)
        {{$product->product_name}}
        {{$product->product_price}}
        <form action="{{action('Admin\ProductController@deleteItem')}}" method="post">
            {{csrf_field()}}
            <button name="deleteitem" value="{{$key}}" >Delete</button>

            <input type="hidden" name="prid" value="{{$id=$pid}}">
        </form>
        @endif
    @endforeach



   @endforeach

   <br><label for="total price">Total Price</label>   {{$total}}
    <button name="checkout"id="checkout">Check Out</button>



@endsection