@extends('ecommerce.back_end.layout.master')

@section('title' , 'Create Product');

@section('content')
    @include('ecommerce.back_end.partials.required')
    <h4>Create Product</h4>
    <form action="{{route('admin.product.update',$products->id)}}" method="post" class="form-horizontal col-md-6" enctype="multipart/form-data">
        <input type="hidden" name="_method" value="PUT">
        {{csrf_field()}}
        <div class="form-group">
            <label for="product_name">Name:</label>
            <input type="text" name="product_name" class="form-control" placeholder="Enter Product Name" value="{{$products->product_name}}">
        </div>
        <div class="form-group">
            <label for="price">Price:</label>
            <input type="text" name="product_price" class="form-control" placeholder="Enter Product Price" value="{{$products->product_price}}">
        </div>
        <div class="form-group">
            <label for="product_condition">Condition</label>
            <input type="text" name="product_condition" class="form-control" placeholder="Enter Product Condition" value="{{$products->product_condition}}">
        </div>

        <div class="form-group">
            <label for="product_qty">QTY</label>
            <input type="text" name="product_qty" class="form-control" placeholder="Enter Product Qty" value="{{$products->product_qty}}">
        </div>

        <div class="form-group">
            <label for="product_description">Description</label>
              <textarea class="form-control" name="product_description" cols="30" rows="10">{{$products->product_description}}
              </textarea>
        </div>
        <input type="text" name="categories_id" value="{{$products->subcategories->name}}" readonly>
        <div class="form-group">
            <label for="sub_category">Choose Subcategory</label>
            <select name="subcategories_id" id="subcategories_id" class="form-control">
                @foreach($subcategories as $subcategory)
                    <option value="{{$subcategory->id}}}">{{$subcategory->name}}</option>
                @endforeach
            </select>
        </div>
        <input type="text" name="categories_id" value="{{$products->categories->name}}" readonly>
        <div class="form-group">
            <label for="category">Choose Category</label>
            <select name="categories_id" id="categories_id" class="form-control">
                @foreach($categories as $category)
                    <option value="{{$category->id}}}">{{$category->name}}</option>
                @endforeach
            </select>
        </div>

        <img src="{{URL::to('/')}}/images/{{$products->image}}">
        <div class="form-group">
            <input type="file" name="image" id="image">
        </div>
        <div class="form-group">
            <button class="btn btn-primary" >Save</button>
        </div>
    </form>
@endsection
