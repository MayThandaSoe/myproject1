@extends('ecommerce.back_end.layout.master')

@section('title','Show Sub Categoires')

@section('content')

    @include('ecommerce.back_end.partials.alerts')

    @foreach($products as $product)
        <div class="form-group">
            <strong>{{$product->product_name}}</strong>
            <strong>{{$product->subcategories->name}}</strong>
            <strong>{{$product->categories->name}}</strong>
            <strong>{{$product->product_price}}</strong>
            <ul><li><img src="{{URL::to('/')}}/images/{{$product->image}}" width="200" height="200"></li></ul>
            <form action="{{action('Admin\ProductController@ShoppingCart')}}" method="post"  >
                {{csrf_field()}}
           <button id="Addtocart" name="Addtocart" onclick="this.disabled=true;">Add to Cart</button>
                <input type="hidden" id="item_id" name="item_id" value="{{$product->id}}">
                <input type="hidden" id="product_price" name="product_price" value="{{$product->product_price}}">



           </form>



        </div>
    @endforeach
    @endsection
