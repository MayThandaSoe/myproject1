@extends('ecommerce.back_end.layout.master')

@section('title','Show Sub Categoires')

@section('content')
    <h4>All Sub Categoires</h4>
    <a href="{{route('admin.product.create')}}" class="btn btn-info">Create Product</a>
    <hr>
    @include('ecommerce.back_end.partials.alerts')

     <div class="form-group">
         <form action="{{action('Admin\ProductController@search')}}" method="post" class="form-horizontal col-md-6">
             {{csrf_field()}}
      <input type="text" name="search" id="search">
             <button class="btn btn-primary" >Search</button>

    </form>
     </div>
    @foreach($products as $product)
        <div class="form-group">
            <strong>{{$product->product_name}}</strong>
            <strong>{{$product->subcategories->name}}</strong>
            <strong>{{$product->categories->name}}</strong>
            <ul><li><img src="{{URL::to('/')}}/images/{{$product->image}}" width="200" height="200"></li></ul>

            <a href="{{route('admin.product.edit',$product->id)}}" class="btn btn-info">Edit Products</a>
            <form action="{{route('admin.product.destroy',$product->id)}}" method="post">
                <input type="hidden" name="_method" value="DELETE">
                {{csrf_field()}}
                <button class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this item?');">Delete</button>
            </form>



        </div>
    @endforeach



    @endsection