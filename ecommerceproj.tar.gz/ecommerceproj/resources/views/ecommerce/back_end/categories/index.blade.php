    @extends('ecommerce.back_end.layout.master')

    @section('title','Show Categories')



    @section('content')

        <h4>Show All Categories</h4>
            <a href="{{route('admin.category.create')}}" class="btn btn-info">Create Categories</a>
            <hr>
            @include('ecommerce.back_end.partials.alerts')
            @foreach($categories as $category)
                <div class="form-group">
                    <strong>{{$category->name}}</strong>
                    <a href="{{route('admin.category.edit',$category->id)}}" class="btn btn-info">Edit Categories</a>
                    <form action="{{route('admin.category.destroy',$category->id)}}" method="post">
                        <input type="hidden" name="_method" value="DELETE">
                        {{csrf_field()}}
                        <button class="btn btn-danger" onclick="return confirm('Are You Sure to Delete')";>Delete</button>
                    </form>
                </div>
            @endforeach

        @endsection


