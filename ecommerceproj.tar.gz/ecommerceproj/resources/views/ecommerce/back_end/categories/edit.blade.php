@extends('ecommerce.back_end.layout.master')

@section('title','Edit Category')




@section('content')

    <h4>Edit Categories</h4>
    @include('ecommerce.back_end.partials.required')
    <form action="{{route('admin.category.update',$category->id) }}" class="form-horizontal col-md-6" method="post">
        <input type="hidden" name="_method" value="PUT">
        {{csrf_field()}}
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text"name="name" class="form-control" value="{{$category->name}}">
        </div>
        <button class="btn btn-primary">Update
        </button>

    </form>
@endsection
