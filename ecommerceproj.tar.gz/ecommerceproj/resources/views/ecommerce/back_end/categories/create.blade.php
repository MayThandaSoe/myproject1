@extends('ecommerce.back_end.layout.master')

@section('title','Create Categories')


@section('content')
    @include('ecommerce.back_end.partials.required')
    <h4>Create Categories</h4>
    <form action="{{route('admin.category.store') }}" class="form-horizontal col-md-6" method="post">
        {{csrf_field()}}
        <div class="form-group">
            <label for="Category Name" class="control-label col-sm-3">Category Name:</label>
            <div class="col-sm-9">
                <input type="text" name="name" class="form-control">
            </div>
        </div>
        <div class="col-sm-9 col-md-offset-3">
            <button class="btn btn-primary">Save
            </button>
       </div>

    </form>
@endsection
