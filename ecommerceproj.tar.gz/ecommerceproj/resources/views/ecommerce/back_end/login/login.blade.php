@extends('ecommerce.back_end.layout.master)

@section('title','Login')

@section('content')
    @include('ecommerce.back_end.partials.required')
    <form action="{{route('user_login')}}" method="post" class="form-horizontal col-md-6">
            {{csrf_field()}}
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="text" name="email" class="form-control" placeholder="Enter Email">
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="text" name="password" class="form-control" placeholder="Enter Password">
        </div>
        <div class="form-group">
            <button class="btn btn-primary">Login</button>
        </div>
    </form>
@endsection