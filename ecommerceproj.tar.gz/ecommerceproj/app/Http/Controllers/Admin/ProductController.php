<?php

namespace App\Http\Controllers\Admin;

use App\Models\Category;
use App\Models\Product;
use App\Models\Subcategory;
use DoctrineTest\InstantiatorTestAsset\SerializableArrayObjectAsset;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Session;
use File;



class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {

       $products    = Product::all();
       return view('ecommerce.back_end.products.index',compact('products'));

    }

    /**
     * Show the form for creating a resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $subcategories = Subcategory::all();
        $categories = Category::all();
        return view('ecommerce.back_end.products.create',compact('subcategories','categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Product::create($request->all());
        $imageName = $request->file('image');
        $path     = public_path('images');


        if($imageName != null)
        {

            $extension = $imageName->getClientOriginalExtension();
            $filename  = rand(11111,99999).'.'.$extension;
            $request->file('image')->move(

                $path, $filename) ;



        }


        $images = Product::Create($request->all());
        $images->image = $filename;
        $images->save();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $products       = Product::find($id);
        $subcategories = Subcategory::all();
        // $sub_id        = $subcategories->categories_id;
        // $categoriesbyid  = Category::with('subcategories')->where('id','=',$sub_id)->get();
        $categories      = Category::all();

        return view('ecommerce.back_end.products.edit',compact('products','subcategories','categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $products = Product::find($id);
       // File::delete(public_path('images/').$products->image);
        //dd(File::delete(URL::to('/').'/images/'.$images->imagename));

        $imageName = $request->file('image');
        $path     = public_path('images');


        if($imageName != null)
        {
            File::delete(public_path('images/').$products->image);
            $extension = $imageName->getClientOriginalExtension();
            $filename  = rand(11111,99999).'.'.$extension;
            $request->file('image')->move(

                $path, $filename) ;



        }
        else
        {
            $filename = $products->image;

         }


        $images=Product::find($id)->fill($request->all());
        $images->image = $filename;
        $images->save();
      //  Product::find($id)->fill($request->all())->save();
        return redirect()->route('admin.product.index')->with('message','Product Update');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Product::find($id)->delete();
        return redirect()->route('admin.product.index')->with('message','Product Delete');


    }
    public function search()
    {

        $q = Input::get('search');
        $products = Product::join('subcategories','products.subcategories_id','=','subcategories.id')->join('categories','categories.id','=','products.categories_id')
                       -> where('product_name','LIKE','%'.$q.'%')
                  ->orwhere('product_price','LIKE','%'.$q.'%')
                  ->orwhere('subcategories.name','LIKE','%'.$q.'%')
                  ->orwhere('categories.name','LIKE','%'.$q.'%')
                  ->get();

            

        return view('ecommerce.back_end.products.index',compact('products'));
    }



    public function showproduct()
    {
        $products    = Product::all();
        return view('ecommerce.back_end.products.show',compact('products'));
    }
    public function ShoppingCart()
    {

        $id = Input::get('item_id');


        if(Session::has('productcart')) {
            
            $products = Session::get('productcart');
            $products[] = $id;
            Session::put('productcart',$products);

        }
        else
        {
            Session::put('productcart',array($id));
        }

        $products    = Product::all();
        return view('ecommerce.back_end.products.show',compact('products'));


       // $datas = Session::get('productcart');

       // return view('ecommerce.back_end.products.cart',compact('datas'));

     }
    Public function RemoveItem()
    {
        $datas = Session::get('productcart');
       // dd($datas);

        return view('ecommerce.back_end.products.cart',compact('datas'));

    }
    public  function  deleteItem()

    {
         $delid = Input::get('deleteitem');

      //   dd($delid);
         Session::forget('productcart.'.$delid);

        $datas = Session::get('productcart');
       


        return view('ecommerce.back_end.products.cart',compact('datas'));

    }
}
