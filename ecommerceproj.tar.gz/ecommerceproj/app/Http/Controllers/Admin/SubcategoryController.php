<?php

namespace App\Http\Controllers\Admin;

use App\Models\Category;
use App\Models\Subcategory;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Requests\SubcategoryRequest;


class SubcategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $subcategories = Subcategory::all();
        return view('ecommerce.back_end.sub_categories.index',compact('subcategories'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $subcategories = Subcategory::all();

        $categories    = Category::all();
        return view('ecommerce.back_end.sub_categories.create',compact('subcategories','categories'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(SubcategoryRequest $request)
    {
        Subcategory::create($request->all());

        return redirect()->route('admin.subcategory.index')->with('message','Create Subcategory');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $subcategories = Subcategory::Find($id);
       // $sub_id        = $subcategories->categories_id;
       // $categoriesbyid  = Category::with('subcategories')->where('id','=',$sub_id)->get();
        $categories      = Category::all();

        return view('ecommerce.back_end.sub_categories.edit',compact('subcategories','categories'));//'categoriesbyid','categories'));//'cat_names'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(SubcategoryRequest $request, $id)
    {
        Subcategory::find($id)->fill($request->all())->save();
        return redirect()->route('admin.subcategory.index')->with('message','Subcategory Update');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Subcategory::find($id)->delete();
        return redirect()->route('admin.subcategory.index')->with('message','Subcategory Delete');

    }
}
