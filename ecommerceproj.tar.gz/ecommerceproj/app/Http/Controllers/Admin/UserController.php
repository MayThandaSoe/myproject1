<?php

namespace App\Http\Controllers\Admin;

use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Controllers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Sentinel;
use Activation;
use Crypt;
class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::all();
        return view('ecommerce.back_end.users.index',compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $roles = Role::all();

        return view('ecommerce.back_end.users.create',compact('roles'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $userdata = $request->all();
        $rules = [
            'first_name'    => 'required',
            'last_name'     => 'required',
            'email'         => 'required|email|unique:users,email',
            'password'      => 'required|min:4|confirmed',
            'password_confirmation'  => 'required|min:4'
        ];

        $validator = Validator::make($userdata, $rules);
        if($validator->fails()) {
            return redirect("register")->withErrors($validator)->withInput(Request::old());
        }

     //  $user= Sentinel::register([
       //     'email'      => $request->input('email'),
         //   'password'  => $request->input('password'),
         //   'first_name'    => $request->input('first_name'),
          //  'last_name'     => $request->input('last_name'),
          //  'permissions'    => ['admin'=> true],


       // ]);

     //  $activation = Activation::create($user);
        // return "localhost:8000/activate/".$user->id."/".$activation->code;

        $user = User::create($request->all());
        $user->password = bcrypt($request->input('password'));
        $user->save();
        $activation_code = '$%&1234';

         return "localhost:8000/activate/".$user->id."/".$activation_code;





        //  $user = Sentinel::registerAndActivate($userdata);


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::find($id);
       // $value= Crypt::decrypt($user->password);
        return view('ecommerce.back_end.users.edit',compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $user = Sentinel::findById($id);
        $credentials=[
            'email'      => $request->input('email'),
            'password'  => $request->input('password'),
            'first_name'    => $request->input('first_name'),
            'last_name'     => $request->input('last_name'),
        ];
        $user = Sentinel::update($user,$credentials);
        //User::find($id)->fill($request->all())->save();
        return redirect()->route('admin.user.index')->with('message','Users Update');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Sentinel::findById($id)->delete();
        return redirect()->route('admin.user.index')->with('message','Users Delete');
    }
}
