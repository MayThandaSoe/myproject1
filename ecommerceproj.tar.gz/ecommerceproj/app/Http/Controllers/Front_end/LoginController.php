<?php

namespace App\Http\Controllers\Front_end;
use App\Models\Product;
use App\Models\User;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use App\Http;
class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('ecommerce.front_end.login');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $userdata = Input::except("_token");
        $this->validate($request, [
            'email' => 'required',
            'password' => 'required|min:4',

        ]);

        if (Auth::attempt($userdata)) {

            if(Auth::check())
            {
                $email = $userdata['email'];
                $user = User::where('email',$email)->first(['id']);
                $id  = $user->id;


                Session::put('id', $id);

                $user_role = User::join('roles','users.role_id','=','roles.id')->where('email',$email)->first(['roles.name']);;
                if($user_role != null) {
                    if ($user_role->name == 'admin') {
                        echo 'you are admin';
                    }
                }
                else
                {
                    echo "you are not admin";
                }
            }


        } else {

            // validation not successful, send back to form
             echo 'do not login';

        }


    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
