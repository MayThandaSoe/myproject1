<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

get('designtest' ,function()
{
   return view("ecommerce.back_end.categories.index");
});

Route::resource('admin/user','Admin\UserController');

Route::resource('admin/category','Admin\CategoryController');

Route::resource('admin/subcategory','Admin\SubcategoryController');

Route::resource('admin/product','Admin\ProductController');
Route::resource('front_end/login','Front_end\LoginController');
Route::resource('front_end/user','Front_end\UserController');

post('search',array('uses' => 'Admin\ProductController@search'));

get('cart','Admin\ProductController@showproduct');
post('cart',array('uses' => 'Admin\ProductController@ShoppingCart'));

get('showcart','Admin\ProductController@RemoveItem');
post('showcart',array('uses' => 'Admin\ProductController@deleteItem'));

get('activate/{id}/{code}', function($id){

    $user = \App\Models\User::find($id);
    $user->activate = '1';
    $user->save();

    if($user->activate == 1)
    {
        return redirect()->route('admin.user.index')->with('message','Show Users');
    }

   // if (Activation::complete($user,$code))
   // {
       
    //    return redirect()->route('admin.user.index')->with('message','Show Users');
   // }
  //  else {

   // }
});
