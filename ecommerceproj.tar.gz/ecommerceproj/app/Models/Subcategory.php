<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Subcategory extends Model
{
    protected $fillable = ['name', 'categories_id'];

    public function categories()
    {
        return $this->belongsTo('App\Models\Category');
    }
   public function products()
    {
         $this->hasMany('App\Models\Product','subcategories_id');
    }

}
