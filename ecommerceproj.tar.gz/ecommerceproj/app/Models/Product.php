<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = ['product_name','product_price','product_condition','product_qty','product_description','subcategories_id','categories_id','image'];

    public function subcategories()
    {
        return $this->belongsTo('App\Models\Subcategory');
    }
    public function categories()
    {
        return $this->belongsTo('App\Models\Category');
    }

}
