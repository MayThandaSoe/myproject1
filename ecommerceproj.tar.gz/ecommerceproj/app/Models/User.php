<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    protected $fillable = ['first_name', 'last_name','email','password','role_id','activate','last_login'];

    public function role()
    {
        return $this->belongsTo('App\Models\Role');
    }

}
